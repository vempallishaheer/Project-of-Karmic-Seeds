# Submission Checklist

- [x] Working Streamlit application
- [x] Dummy operational data
- [x] Dashboard
- [x] Priority queue
- [x] Inventory visibility
- [x] Picking/packing workflow view
- [x] Shipping/staging view
- [x] Issue tracker
- [x] README with local setup
- [x] 5-minute walkthrough script
- [x] AI usage note
- [x] .gitignore

## Before submission
1. Run `streamlit run app.py`.
2. Test every page.
3. Record a walkthrough of 5 minutes or less.
4. Push the project to GitHub.
5. Verify the README from a clean environment.
6. Submit the GitHub or hosted-app URL.
