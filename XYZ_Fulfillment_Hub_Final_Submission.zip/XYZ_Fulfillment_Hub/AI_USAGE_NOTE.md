# AI Usage Note

AI was used as a development aid for:
- brainstorming the fulfillment workflow and operational data model
- generating an initial set of dummy data
- creating the first Streamlit application structure
- suggesting UI organization and business-rule ideas
- drafting documentation and walkthrough material

Human decisions and validation included selecting the operational problems to prioritize, defining the fulfillment workflow, separating the Priority Queue, defining the inventory transfer rule, designing the attention queue, deciding the picking/variant verification concept, and keeping the interface simple for warehouse users.

The generated sample data was reviewed and adjusted to demonstrate realistic exceptions such as priority orders, delays, stock shortages, secondary-warehouse stock, missed pickups and fulfillment issues.

AI output was treated as a starting point and reviewed before incorporation.
