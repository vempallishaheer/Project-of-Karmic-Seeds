# 5-Minute Walkthrough — XYZ Fulfillment Hub

## 0:00–0:30 — Problem
XYZ handles roughly 200–300 orders per day. The fulfillment workflow needs better visibility across order status, priority orders, inventory, picking, packing, staging and courier pickup.

## 0:30–1:00 — Approach
I designed a lightweight Fulfillment Hub around:
Order Received → Processing → Picking → Packing → Staging → Shipping.

I focused on order visibility, priority handling, inventory visibility, picking verification, and shipping/issue follow-up.

## 1:00–2:00 — Dashboard
The dashboard shows total orders, active orders, priority orders, delayed orders, ready-for-pickup shipments and open issues. The Attention Queue surfaces priority and delayed orders, while Inventory Alerts identify replenishment or transfer needs.

## 2:00–2:45 — Orders and Priority Queue
The Orders page supports Order ID search and filters. The Priority Queue is separated so high-priority orders are not buried in the general queue, with delayed orders surfaced first.

## 2:45–3:30 — Inventory and Picking
Inventory compares main and secondary warehouse stock. When main stock is unavailable but secondary stock exists, the application flags a transfer. Picking & Packing shows product, variant, quantity and priority, with stock warnings.

## 3:30–4:15 — Shipping and Issues
Shipping keeps ready-for-pickup and missed-pickup shipments visible. The Issue Tracker keeps operational problems visible until resolved.

## 4:15–4:45 — Design choices
I kept the interface simple because the warehouse team is experienced but not necessarily comfortable with complex technology. The goal is a practical operational control layer.

## 4:45–5:00 — Close
The result is one operational view connecting orders, priority handling, inventory, picking, packing, shipping and issues. A production version could connect to real order, inventory and courier systems and persist status changes in a database.
