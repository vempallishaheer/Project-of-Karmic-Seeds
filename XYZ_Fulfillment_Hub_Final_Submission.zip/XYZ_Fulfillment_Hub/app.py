import streamlit as st
import pandas as pd
from pathlib import Path
from datetime import datetime

st.set_page_config(page_title="XYZ Fulfillment Hub", page_icon="📦", layout="wide")

DATA = Path(__file__).parent / "data"

@st.cache_data
def load_data():
    orders = pd.read_csv(DATA/"orders.csv", parse_dates=["OrderDate","Deadline"])
    inventory = pd.read_csv(DATA/"inventory.csv")
    shipments = pd.read_csv(DATA/"shipments.csv", parse_dates=["PickupTime"])
    issues = pd.read_csv(DATA/"issues.csv")
    return orders, inventory, shipments, issues

orders, inventory, shipments, issues = load_data()

# ---------- Business rules ----------
REFERENCE_TIME = pd.Timestamp("2026-09-26 17:00")
orders["Delayed"] = (orders["Deadline"] < REFERENCE_TIME) & (~orders["Status"].eq("Shipped"))
orders["Priority"] = orders["Priority"].eq("High")

inventory["TransferRequired"] = (
    (inventory["AvailableMain"] <= 0) &
    (inventory["AvailableSecondary"] > 0)
)
inventory["LowStock"] = inventory["AvailableMain"] <= inventory["ReorderLevel"]

def refresh():
    st.cache_data.clear()
    st.rerun()

# ---------- Styling ----------
st.markdown("""
<style>
.block-container {padding-top: 1.2rem; padding-bottom: 2rem;}
[data-testid="stMetric"] {
    border: 1px solid rgba(128,128,128,.25);
    padding: 14px;
    border-radius: 12px;
}
.small-note {color: #6b7280; font-size: .9rem;}
.alert-box {
    border: 1px solid rgba(220,38,38,.25);
    border-radius: 12px;
    padding: 12px;
    margin-bottom: 8px;
}
</style>
""", unsafe_allow_html=True)

# ---------- Sidebar ----------
st.sidebar.title("📦 XYZ Fulfillment")
st.sidebar.caption("Operations Control Hub")

pages = [
    "Dashboard", "Orders", "Priority Queue",
    "Inventory", "Picking & Packing", "Shipping", "Issues"
]
page = st.sidebar.radio("Go to", pages)

st.sidebar.divider()
st.sidebar.caption("Demo data: 26 Sep 2026")
if st.sidebar.button("↻ Refresh data", use_container_width=True):
    refresh()

# ---------- Dashboard ----------
if page == "Dashboard":
    st.title("Fulfillment Operations")
    st.caption("One place to see what needs attention now.")

    total = len(orders)
    active = len(orders[orders.Status != "Shipped"])
    priority = len(orders[(orders.Priority) & (orders.Status != "Shipped")])
    delayed = len(orders[orders.Delayed])
    ready = len(shipments[shipments.ShipmentStatus == "Ready for Pickup"])
    issues_open = len(issues[issues.Status != "Resolved"])

    a,b,c,d,e,f = st.columns(6)
    a.metric("Orders", total)
    b.metric("Active", active)
    c.metric("Priority", priority)
    d.metric("Delayed", delayed)
    e.metric("Ready Pickup", ready)
    f.metric("Open Issues", issues_open)

    st.divider()

    left, right = st.columns([1.35, 1])

    with left:
        st.subheader("🚨 Attention Queue")
        attention = orders[
            (orders.Priority) | (orders.Delayed)
        ].copy()
        attention["Urgency"] = attention.apply(
            lambda r: "DELAYED" if r.Delayed else "PRIORITY", axis=1
        )
        attention = attention.sort_values(["Delayed","Deadline"], ascending=[False,True])
        st.dataframe(
            attention[["OrderID","ProductName","Variant","Priority","Status","Deadline","Urgency"]].head(12),
            use_container_width=True, hide_index=True,
            column_config={
                "Deadline": st.column_config.DatetimeColumn(format="DD MMM, HH:mm"),
            }
        )

    with right:
        st.subheader("🏭 Stock Alerts")
        alerts = inventory[inventory.LowStock | inventory.TransferRequired].copy()
        alerts["Action"] = alerts.apply(
            lambda r: "Transfer from secondary" if r.TransferRequired else "Replenish main",
            axis=1
        )
        st.dataframe(
            alerts[["ProductID","Variant","AvailableMain","AvailableSecondary","Action"]],
            use_container_width=True, hide_index=True
        )

    st.subheader("📊 Fulfillment Flow")
    flow = orders["Status"].value_counts().reindex(
        ["Received","Processing","Picking","Packing","Staging","Shipped"], fill_value=0
    )
    st.bar_chart(flow)

# ---------- Orders ----------
elif page == "Orders":
    st.title("📋 Order Management")
    st.caption("Find an order quickly and see where it is in the fulfillment flow.")

    c1,c2,c3,c4 = st.columns(4)
    priority = c1.selectbox("Priority", ["All","High","Normal"])
    status = c2.selectbox("Status", ["All"] + sorted(orders.Status.unique()))
    search = c3.text_input("Search Order ID")
    only_delayed = c4.checkbox("Delayed only")

    df = orders.copy()
    if priority != "All": df = df[df.Priority.map({True:"High",False:"Normal"}) == priority]
    if status != "All": df = df[df.Status == status]
    if search: df = df[df.OrderID.str.contains(search, case=False, na=False)]
    if only_delayed: df = df[df.Delayed]

    st.write(f"**{len(df)}** matching orders")

    st.dataframe(
        df[["OrderID","Customer","ProductName","Variant","Quantity","Priority","Status","Deadline","Delayed"]],
        use_container_width=True, hide_index=True,
        column_config={
            "Deadline": st.column_config.DatetimeColumn(format="DD MMM, HH:mm"),
            "Delayed": st.column_config.CheckboxColumn("Delayed")
        }
    )

    st.divider()
    st.subheader("Order detail")
    selected = st.selectbox("Select an order", df.OrderID.tolist() if not df.empty else ["No matching order"])
    if selected != "No matching order":
        row = df[df.OrderID == selected].iloc[0]
        x,y,z = st.columns(3)
        x.write(f"**Customer:** {row.Customer}")
        y.write(f"**Product:** {row.ProductName} — {row.Variant}")
        z.write(f"**Deadline:** {row.Deadline:%d %b %H:%M}")
        st.info(f"Current stage: **{row.Status}**  •  Priority: **{'HIGH' if row.Priority else 'Normal'}**")

# ---------- Priority ----------
elif page == "Priority Queue":
    st.title("🚨 Priority Queue")
    st.caption("High-priority orders are separated so they do not get lost in the normal queue.")

    df = orders[(orders.Priority) & (orders.Status != "Shipped")].copy()
    df["Risk"] = df.apply(lambda r: "Overdue" if r.Delayed else "Due soon", axis=1)
    df = df.sort_values(["Delayed","Deadline"], ascending=[False,True])

    st.metric("Active priority orders", len(df))
    st.dataframe(
        df[["OrderID","ProductName","Variant","Quantity","Status","Deadline","Risk"]],
        use_container_width=True, hide_index=True
    )

# ---------- Inventory ----------
elif page == "Inventory":
    st.title("🏭 Inventory Control")
    st.caption("Compare main and secondary warehouse stock before promising an order.")

    c1,c2,c3 = st.columns(3)
    c1.metric("Low-stock SKUs", int(inventory.LowStock.sum()))
    c2.metric("Transfer required", int(inventory.TransferRequired.sum()))
    c3.metric("Main units", int(inventory.AvailableMain.sum()))

    inv = inventory.copy()
    inv["Action"] = inv.apply(
        lambda r: "TRANSFER" if r.TransferRequired else ("REPLENISH" if r.LowStock else "OK"), axis=1
    )

    action = st.selectbox("Show", ["All","TRANSFER","REPLENISH","OK"])
    if action != "All":
        inv = inv[inv.Action == action]

    st.dataframe(
        inv[["ProductID","Variant","AvailableMain","AvailableSecondary","ReorderLevel","Action"]],
        use_container_width=True, hide_index=True
    )

# ---------- Picking & Packing ----------
elif page == "Picking & Packing":
    st.title("🛒 Picking & Packing")
    st.caption("Reduce wrong-item shipments by verifying the order before packing.")

    active = orders[orders.Status.isin(["Picking","Packing"])].copy()
    stock_lookup = inventory.set_index("ProductID")

    def check(r):
        stock = stock_lookup.loc[r.ProductID, "AvailableMain"]
        if stock <= 0:
            return "⚠ Main stock unavailable"
        if r.Priority:
            return "★ Priority — verify first"
        return "Ready"

    active["Check"] = active.apply(check, axis=1)

    st.dataframe(
        active[["OrderID","ProductName","Variant","Quantity","Priority","Status","Check"]],
        use_container_width=True, hide_index=True
    )

    st.info("Operational rule: verify Product ID + Variant + Quantity before moving an order from Picking to Packing.")

# ---------- Shipping ----------
elif page == "Shipping":
    st.title("🚚 Shipping & Staging")
    st.caption("Keep packed orders visible until the courier actually collects them.")

    ready = shipments[shipments.ShipmentStatus == "Ready for Pickup"]
    missed = shipments[shipments.ShipmentStatus == "Missed Pickup"]

    a,b,c = st.columns(3)
    a.metric("Ready for pickup", len(ready))
    b.metric("Missed pickups", len(missed))
    c.metric("Picked up", int((shipments.ShipmentStatus == "Picked Up").sum()))

    st.subheader("Pickup queue")
    q = shipments[shipments.ShipmentStatus.isin(["Ready for Pickup","Missed Pickup"])]
    st.dataframe(
        q[["ShipmentID","OrderID","Courier","PickupTime","ShipmentStatus","TrackingStatus"]],
        use_container_width=True, hide_index=True
    )

# ---------- Issues ----------
elif page == "Issues":
    st.title("⚠️ Issue Tracker")
    st.caption("Make operational problems visible until someone closes them.")

    c1,c2,c3 = st.columns(3)
    status = c1.selectbox("Status", ["All"] + sorted(issues.Status.unique()))
    typ = c2.selectbox("Issue type", ["All"] + sorted(issues.IssueType.unique()))
    pri = c3.selectbox("Priority", ["All"] + sorted(issues.Priority.unique()))

    df = issues.copy()
    if status != "All": df = df[df.Status == status]
    if typ != "All": df = df[df.IssueType == typ]
    if pri != "All": df = df[df.Priority == pri]

    st.metric("Open issues", len(issues[issues.Status != "Resolved"]))
    st.dataframe(df, use_container_width=True, hide_index=True)

    st.divider()
    st.subheader("Issue detail")
    selected = st.selectbox("Select issue", df.IssueID.tolist() if not df.empty else ["None"])
    if selected != "None":
        issue = df[df.IssueID == selected].iloc[0]
        st.write(f"**{issue.IssueType} — {issue.Priority} priority**")
        st.write(issue.Description)
        st.write(f"Order: **{issue.OrderID}**  |  Status: **{issue.Status}**")
