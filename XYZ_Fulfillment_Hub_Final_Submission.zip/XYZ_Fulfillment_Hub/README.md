# XYZ Fulfillment Hub

A lightweight fulfillment operations control hub for the XYZ take-home project.

## Solution
The application provides one operational view across:

**Order Received → Processing → Picking → Packing → Staging → Shipping**

### Key capabilities
- Dashboard with operational KPIs
- Priority-order queue
- Delayed-order visibility
- Main/secondary inventory comparison
- Stock transfer and replenishment alerts
- Picking and packing verification
- Courier pickup and missed-pickup tracking
- Issue tracking
- Search and filtering

## Technology
Python, Streamlit, Pandas and CSV sample data.

## Run locally

### Windows
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

### macOS/Linux
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Project structure
```text
XYZ_Fulfillment_Hub/
├── app.py
├── requirements.txt
├── README.md
├── AI_USAGE_NOTE.md
├── SUBMISSION_CHECKLIST.md
├── docs/
│   └── WALKTHROUGH_SCRIPT.md
└── data/
    ├── orders.csv
    ├── products.csv
    ├── inventory.csv
    ├── warehouses.csv
    ├── shipments.csv
    └── issues.csv
```

## Demo data
The included data intentionally contains priority orders, delayed orders, stock shortages, secondary-warehouse availability, missed pickups and operational issues.

## Production improvements
Connect to real order, inventory and courier systems; persist changes in a database; add authentication/roles, audit history, notifications, courier APIs and barcode scanning.
